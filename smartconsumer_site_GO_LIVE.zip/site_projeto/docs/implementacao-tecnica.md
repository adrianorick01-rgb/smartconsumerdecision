# Guia de Implementação Técnica

## Configuração dos Hoplinks

### Estrutura JSON dos Hoplinks
O arquivo `config/hoplinks_organizados.json` contém a estrutura completa dos hoplinks organizados por categoria.

### Implementação em JavaScript

```javascript
// Carregar configuração de hoplinks
async function carregarHoplinks() {
    const response = await fetch('./config/hoplinks_organizados.json');
    return await response.json();
}

// Função para produtos individuais
function redirecionarProduto(produtoId) {
    const hoplinks = carregarHoplinks();
    const produto = hoplinks.produtos[produtoId];
    if (produto) {
        window.open(produto.hoplink, '_blank');
    }
}

// Função para kits (múltiplos produtos)
function redirecionarKit(kitId) {
    const hoplinks = carregarHoplinks();
    const kit = hoplinks.kits[kitId];
    if (kit) {
        // Abrir produto principal
        const produtoPrincipal = hoplinks.produtos[kit.produto_principal.toLowerCase().replace(/[^a-z0-9]/g, '_')];
        if (produtoPrincipal) {
            window.open(produtoPrincipal.hoplink, '_blank');
        }
        
        // Abrir produtos complementares com delay
        kit.produtos_complementares.forEach((produto, index) => {
            setTimeout(() => {
                const produtoComplementar = hoplinks.produtos[produto.toLowerCase().replace(/[^a-z0-9]/g, '_')];
                if (produtoComplementar) {
                    window.open(produtoComplementar.hoplink, '_blank');
                }
            }, (index + 1) * 1000); // 1 segundo de delay entre cada produto
        });
    }
}
```

### Implementação em HTML

#### Para Produtos Individuais
```html
<button onclick="redirecionarProduto('ageless_knees')" class="btn-comprar">
    Comprar Ageless Knees
</button>
```

#### Para Kits
```html
<button onclick="redirecionarKit('vitalidade_50')" class="btn-comprar-kit">
    Comprar Kit Vitalidade 50+
</button>
```

## Estrutura de Páginas Recomendada

### Página de Produto Individual
```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[NOME_PRODUTO] - Análise Completa</title>
    <link rel="stylesheet" href="../assets/css/produto.css">
</head>
<body>
    <header>
        <img src="../assets/Logo/main-logo-dark.png" alt="Logo">
    </header>
    
    <main>
        <section class="hero">
            <h1>[NOME_PRODUTO]</h1>
            <p class="subtitulo">[DESCRIÇÃO_BREVE]</p>
        </section>
        
        <section class="analise">
            <!-- Conteúdo da análise do produto -->
        </section>
        
        <section class="cta">
            <button onclick="redirecionarProduto('[ID_PRODUTO]')" class="btn-comprar">
                Comprar Agora
            </button>
        </section>
        
        <section class="disclaimer">
            <p>*Individual results may vary. SmartConsumerDecision.com is not affiliated with the FDA or any pharmaceutical company. Testimonials reflect real experiences.</p>
        </section>
    </main>
    
    <script src="../assets/js/hoplinks.js"></script>
</body>
</html>
```

### Página de Kit
```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[NOME_KIT] - Kit Completo</title>
    <link rel="stylesheet" href="../assets/css/kit.css">
</head>
<body>
    <header>
        <img src="../assets/Logo/main-logo-dark.png" alt="Logo">
    </header>
    
    <main>
        <section class="hero">
            <h1>[NOME_KIT]</h1>
            <p class="subtitulo">Kit completo com produtos selecionados</p>
        </section>
        
        <section class="produtos-inclusos">
            <h2>Produtos Inclusos</h2>
            <!-- Lista dos produtos do kit -->
        </section>
        
        <section class="cta">
            <button onclick="redirecionarKit('[ID_KIT]')" class="btn-comprar-kit">
                Comprar Kit Completo
            </button>
            <p class="observacao">Adicione o link individual de cada produto para usuário</p>
        </section>
        
        <section class="disclaimer">
            <p>*Individual results may vary. SmartConsumerDecision.com is not affiliated with the FDA or any pharmaceutical company. Testimonials reflect real experiences.</p>
        </section>
    </main>
    
    <script src="../assets/js/hoplinks.js"></script>
</body>
</html>
```

## CSS Recomendado

### Estilos Base
```css
/* Reset e base */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Arial', sans-serif;
    line-height: 1.6;
    color: #333;
}

/* Botões de CTA */
.btn-comprar, .btn-comprar-kit {
    background: linear-gradient(45deg, #ff6b6b, #ee5a24);
    color: white;
    padding: 15px 30px;
    border: none;
    border-radius: 5px;
    font-size: 18px;
    font-weight: bold;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
}

.btn-comprar:hover, .btn-comprar-kit:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
}

/* Disclaimer */
.disclaimer {
    background: #f8f9fa;
    padding: 20px;
    margin-top: 40px;
    border-left: 4px solid #007bff;
}

.disclaimer p {
    font-size: 12px;
    color: #666;
    font-style: italic;
}
```

## Otimizações Recomendadas

### SEO
1. Meta tags específicas para cada produto
2. Schema markup para produtos
3. URLs amigáveis
4. Sitemap XML

### Performance
1. Lazy loading para imagens
2. Minificação de CSS/JS
3. Compressão de imagens
4. CDN para assets

### Conversão
1. A/B testing nos botões de CTA
2. Heatmaps para análise de comportamento
3. Analytics de conversão
4. Otimização mobile-first

## Conformidade e Segurança

### Disclaimers Obrigatórios
Todos os produtos devem incluir o disclaimer padrão:
```
*Individual results may vary. SmartConsumerDecision.com is not affiliated with the FDA or any pharmaceutical company. Testimonials reflect real experiences.
```

### Políticas de Privacidade
Implementar política de privacidade conforme LGPD/GDPR.

### Tracking
Configurar Google Analytics e Facebook Pixel para tracking de conversões.

