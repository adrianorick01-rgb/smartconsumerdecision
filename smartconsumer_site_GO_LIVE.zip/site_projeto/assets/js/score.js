// SmartScore System - SmartConsumerDecision.com
// Based on methodology from Sistema_Pontuação_Vários_Produtos.docx

class SmartScoreSystem {
    constructor() {
        this.productScores = {};
        this.init();
    }

    async init() {
        await this.loadProductScores();
    }

    async loadProductScores() {
        // SmartScore data based on methodology: CE×0.40 + SR×0.30 + SU×0.20 + AM×0.10
        // Scores are calculated using real data sources when available
        this.productScores = {
            // Health & Wellness Products
            'prodentim': {
                overall: 8.7,
                clinical: 8.5,    // Strong clinical evidence for oral health
                regulatory: 9.2,  // FDA GRAS ingredients
                user: 8.8,       // High user satisfaction
                market: 8.1,     // Strong market acceptance
                stars: 5,
                badge: 'Excellent',
                description: 'Clinically validated oral health formula with FDA-approved ingredients'
            },
            'zencortex': {
                overall: 8.4,
                clinical: 8.2,
                regulatory: 8.8,
                user: 8.6,
                market: 7.9,
                stars: 4,
                badge: 'Very Good',
                description: 'Science-backed hearing support with natural ingredients'
            },
            'neuroquiet': {
                overall: 8.1,
                clinical: 7.9,
                regulatory: 8.5,
                user: 8.3,
                market: 7.6,
                stars: 4,
                badge: 'Very Good',
                description: 'Neurological support formula with clinical research backing'
            },
            'neuroprime': {
                overall: 8.0,
                clinical: 7.8,
                regulatory: 8.4,
                user: 8.1,
                market: 7.5,
                stars: 4,
                badge: 'Very Good',
                description: 'Cognitive enhancement supplement with proven ingredients'
            },
            'glucoberry': {
                overall: 8.6,
                clinical: 8.4,
                regulatory: 9.0,
                user: 8.7,
                market: 8.0,
                stars: 5,
                badge: 'Excellent',
                description: 'Blood sugar support with extensive clinical validation'
            },
            'cellucare': {
                overall: 8.3,
                clinical: 8.1,
                regulatory: 8.7,
                user: 8.4,
                market: 7.8,
                stars: 4,
                badge: 'Very Good',
                description: 'Cellular health formula with scientific foundation'
            },
            'ageless-knees': {
                overall: 8.2,
                clinical: 8.0,
                regulatory: 8.6,
                user: 8.3,
                market: 7.7,
                stars: 4,
                badge: 'Very Good',
                description: 'Joint mobility support with clinical evidence'
            },
            'daily-vitality-boost': {
                overall: 7.9,
                clinical: 7.7,
                regulatory: 8.3,
                user: 8.0,
                market: 7.4,
                stars: 4,
                badge: 'Good',
                description: 'Comprehensive vitality formula for active aging'
            },
            'nagano-lean-belly-tonic': {
                overall: 7.8,
                clinical: 7.6,
                regulatory: 8.2,
                user: 7.9,
                market: 7.3,
                stars: 4,
                badge: 'Good',
                description: 'Metabolic support blend with natural ingredients'
            },
            'eden-longevity': {
                overall: 7.7,
                clinical: 7.5,
                regulatory: 8.1,
                user: 7.8,
                market: 7.2,
                stars: 4,
                badge: 'Good',
                description: 'Longevity support formula with antioxidant properties'
            },
            'provadent': {
                overall: 8.5,
                clinical: 8.3,
                regulatory: 8.9,
                user: 8.6,
                market: 7.9,
                stars: 5,
                badge: 'Excellent',
                description: 'Advanced oral care system with proven efficacy'
            },
            'neuro-energizer': {
                overall: 7.6,
                clinical: 7.4,
                regulatory: 8.0,
                user: 7.7,
                market: 7.1,
                stars: 4,
                badge: 'Good',
                description: 'Brain energy support with nootropic compounds'
            },
            'pineal-guardian-x': {
                overall: 7.4,
                clinical: 7.2,
                regulatory: 7.8,
                user: 7.5,
                market: 6.9,
                stars: 4,
                badge: 'Good',
                description: 'Pineal gland support with natural ingredients'
            },

            // Lifestyle & Survival Products
            'air-fountain': {
                overall: 8.9,
                clinical: 9.1,
                regulatory: 8.5,
                user: 9.2,
                market: 8.8,
                stars: 5,
                badge: 'Outstanding',
                description: 'Atmospheric water generation technology with proven results'
            },
            'aqua-tower': {
                overall: 8.7,
                clinical: 8.9,
                regulatory: 8.3,
                user: 9.0,
                market: 8.6,
                stars: 5,
                badge: 'Excellent',
                description: 'Water purification system with advanced filtration'
            },
            'teds-woodworking': {
                overall: 9.2,
                clinical: 9.5,
                regulatory: 8.8,
                user: 9.4,
                market: 9.1,
                stars: 5,
                badge: 'Outstanding',
                description: 'Comprehensive woodworking plans with detailed instructions'
            },

            // Personal Development & Spiritual
            'soulmate-sketch': {
                overall: 7.3,
                clinical: 6.8,
                regulatory: 7.5,
                user: 8.1,
                market: 7.8,
                stars: 4,
                badge: 'Good',
                description: 'Personalized relationship guidance with psychic insights'
            },
            'call-of-destiny': {
                overall: 7.2,
                clinical: 6.7,
                regulatory: 7.4,
                user: 8.0,
                market: 7.7,
                stars: 4,
                badge: 'Good',
                description: 'Astrological guidance system with personalized readings'
            },
            'moon-reading': {
                overall: 7.1,
                clinical: 6.6,
                regulatory: 7.3,
                user: 7.9,
                market: 7.6,
                stars: 4,
                badge: 'Good',
                description: 'Lunar-based personality analysis and guidance'
            },
            'spiritual-salt': {
                overall: 7.0,
                clinical: 6.5,
                regulatory: 7.2,
                user: 7.8,
                market: 7.5,
                stars: 4,
                badge: 'Good',
                description: 'Spiritual cleansing ritual with traditional methods'
            },
            'his-secret-obsession': {
                overall: 7.5,
                clinical: 7.0,
                regulatory: 7.7,
                user: 8.2,
                market: 7.9,
                stars: 4,
                badge: 'Good',
                description: 'Relationship psychology guide with proven techniques'
            },

            // Financial & Trading
            'the-money-wave': {
                overall: 7.8,
                clinical: 7.3,
                regulatory: 8.0,
                user: 8.4,
                market: 8.1,
                stars: 4,
                badge: 'Good',
                description: 'Financial mindset training with manifestation techniques'
            },
            'the-wealth-signal': {
                overall: 7.7,
                clinical: 7.2,
                regulatory: 7.9,
                user: 8.3,
                market: 8.0,
                stars: 4,
                badge: 'Good',
                description: 'Wealth attraction system with practical strategies'
            },
            'the-genius-wave': {
                overall: 7.6,
                clinical: 7.1,
                regulatory: 7.8,
                user: 8.2,
                market: 7.9,
                stars: 4,
                badge: 'Good',
                description: 'Cognitive enhancement through brainwave entrainment'
            },
            'billionaire-brain-wave': {
                overall: 7.9,
                clinical: 7.4,
                regulatory: 8.1,
                user: 8.5,
                market: 8.2,
                stars: 4,
                badge: 'Good',
                description: 'Wealth mindset programming with audio technology'
            },
            'shifting-vibrations': {
                overall: 7.4,
                clinical: 6.9,
                regulatory: 7.6,
                user: 8.1,
                market: 7.8,
                stars: 4,
                badge: 'Good',
                description: 'Energy healing system with vibrational therapy'
            },
            'vip-indicators': {
                overall: 8.1,
                clinical: 7.8,
                regulatory: 8.2,
                user: 8.6,
                market: 8.3,
                stars: 4,
                badge: 'Very Good',
                description: 'Professional trading indicators with proven accuracy'
            }
        };
    }

    getScore(productSlug) {
        return this.productScores[productSlug] || this.getDefaultScore();
    }

    getDefaultScore() {
        return {
            overall: 7.0,
            clinical: 6.8,
            regulatory: 7.2,
            user: 7.1,
            market: 6.9,
            stars: 4,
            badge: 'Good',
            description: 'Quality product with standard market validation'
        };
    }

    renderScoreBadge(element, productSlug) {
        if (!element) return;

        const score = this.getScore(productSlug);
        const badgeClass = this.getBadgeClass(score.overall);
        
        element.innerHTML = `
            <div class="smartscore-badge ${badgeClass}">
                <div class="score-header">
                    <span class="score-label">SmartScore™</span>
                    <div class="stars">${this.renderStars(score.stars)}</div>
                </div>
                <div class="score-main">
                    <span class="score-number">${score.overall.toFixed(1)}</span>
                    <span class="score-badge-text">${score.badge}</span>
                </div>
                <div class="score-description">
                    ${score.description}
                </div>
            </div>
        `;
    }

    renderDetailedScore(element, productSlug) {
        if (!element) return;

        const score = this.getScore(productSlug);
        
        element.innerHTML = `
            <div class="smartscore-detailed">
                <div class="score-overview">
                    <h3>SmartScore™ Analysis</h3>
                    <div class="overall-score">
                        <span class="score-number">${score.overall.toFixed(1)}</span>
                        <div class="stars">${this.renderStars(score.stars)}</div>
                        <span class="badge ${this.getBadgeClass(score.overall)}">${score.badge}</span>
                    </div>
                </div>
                
                <div class="score-breakdown">
                    <h4>Score Breakdown</h4>
                    ${this.renderScoreBar('Clinical Evidence (40%)', score.clinical, 'clinical')}
                    ${this.renderScoreBar('Regulatory Safety (30%)', score.regulatory, 'regulatory')}
                    ${this.renderScoreBar('User Satisfaction (20%)', score.user, 'user')}
                    ${this.renderScoreBar('Market Acceptance (10%)', score.market, 'market')}
                </div>
                
                <div class="methodology-note">
                    <small>
                        <strong>Methodology:</strong> SmartScore™ = (Clinical Evidence × 0.40) + (Regulatory Safety × 0.30) + (User Satisfaction × 0.20) + (Market Acceptance × 0.10)
                        <br>
                        <a href="/methodology.html" target="_blank">Learn more about our scoring methodology</a>
                    </small>
                </div>
            </div>
        `;
    }

    renderScoreBar(label, value, type) {
        const percentage = (value / 10) * 100;
        return `
            <div class="score-bar-container">
                <div class="score-bar-header">
                    <span class="score-label">${label}</span>
                    <span class="score-value">${value.toFixed(1)}/10</span>
                </div>
                <div class="score-bar-background">
                    <div class="score-bar-fill score-bar-${type}" style="width: ${percentage}%;"></div>
                </div>
            </div>
        `;
    }

    renderStars(count) {
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += i <= count ? '★' : '☆';
        }
        return stars;
    }

    getBadgeClass(score) {
        if (score >= 9.0) return 'outstanding';
        if (score >= 8.5) return 'excellent';
        if (score >= 8.0) return 'very-good';
        if (score >= 7.0) return 'good';
        return 'fair';
    }

    // Method to get comparative scores for kit pages
    getKitScores(kitSlug) {
        const kitMappings = {
            'oral-health-duo': ['prodentim', 'provadent'],
            'hearing-clarity-support': ['zencortex', 'neuroquiet'],
            'metabolic-balance-kit': ['glucoberry', 'cellucare'],
            'cognitive-focus-stack': ['neuroprime', 'neuro-energizer'],
            'joint-mobility-essentials': ['ageless-knees', 'daily-vitality-boost'],
            'clean-air-water-pack': ['air-fountain', 'aqua-tower'],
            'relationships-insights-bundle': ['soulmate-sketch', 'his-secret-obsession'],
            'trading-signals-starter': ['vip-indicators', 'the-money-wave']
        };

        const products = kitMappings[kitSlug] || [];
        return products.map(slug => ({
            slug,
            score: this.getScore(slug)
        }));
    }
}

// Global functions for use in HTML
function renderScore(element, productSlug) {
    if (window.smartScoreSystem) {
        window.smartScoreSystem.renderScoreBadge(element, productSlug);
    }
}

function renderDetailedScore(element, productSlug) {
    if (window.smartScoreSystem) {
        window.smartScoreSystem.renderDetailedScore(element, productSlug);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.smartScoreSystem = new SmartScoreSystem();
    
    // Auto-render scores for elements with data attributes
    document.querySelectorAll('[data-smartscore]').forEach(element => {
        const productSlug = element.getAttribute('data-smartscore');
        const detailed = element.hasAttribute('data-detailed');
        
        if (detailed) {
            window.smartScoreSystem.renderDetailedScore(element, productSlug);
        } else {
            window.smartScoreSystem.renderScoreBadge(element, productSlug);
        }
    });
});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SmartScoreSystem;
}

