// Enhanced Hoplinks Management - SmartConsumerDecision.com
// Updated with real ClickBank hoplinks from PDF
class HoplinkManager {
    constructor() {
        this.hoplinks = {};
        this.init();
    }

    async init() {
        try {
            await this.loadHoplinks();
        } catch (error) {
            console.error('Error loading hoplinks:', error);
        }
    }

    async loadHoplinks() {
        // Real ClickBank hoplinks from PDF - ID: marcketpro
        this.hoplinks = {
            // Individual Products
            'teds-woodworking': 'https://bb282lfodapr2dpqn13mzxtqcn.hop.clickbank.net',
            'prodentim': 'https://f8138fknedfewbvl-kq0siric8.hop.clickbank.net',
            'daily-vitality-boost': 'https://b9714bhqo9tq-g1f4fbow9nz3t.hop.clickbank.net',
            'nagano-lean-belly-tonic': 'https://32e549kff9fltft7fi07sa2l3y.hop.clickbank.net',
            'eden-longevity': 'https://fb48ahbbohrf2ez2mjx7mo1euw.hop.clickbank.net',
            'eden---longevity-supplement': 'https://fb48ahbbohrf2ez2mjx7mo1euw.hop.clickbank.net',
            'glucoberry': 'https://f03a2cngj8pj2cr9zhr9cc6i4e.hop.clickbank.net',
            'neuroquiet': 'https://c52b4hggn8je4jvanp2lt0i6re.hop.clickbank.net',
            'cellucare': 'https://1052c9qglcrp2hwxoatir1w6c8.hop.clickbank.net',
            'air-fountain': 'https://a3c30ffmkcmr4m194mz6kevnep.hop.clickbank.net',
            'zencortex': 'https://81de1kdkp8qdzp0qihifsffuat.hop.clickbank.net',
            'ageless-knees': 'https://29990gopd9ogtcx8qfztoy6pb6.hop.clickbank.net',
            'soulmate-sketch': 'https://095f9lfojeqkxmsrqrqqv4e-a1.hop.clickbank.net',
            'call-of-destiny': 'https://999d96bdfeolzovzp9fhv4qk5c.hop.clickbank.net',
            'neuroprime': 'https://e34d1ifbd9qlvg-aigzarfp8or.hop.clickbank.net',
            'the-money-wave': 'https://9b62b6kmoiqs-e-j0kji89z4c1.hop.clickbank.net',
            'pineal-guardian-x': 'https://6c2b5gnqsjihwdvdrkklzcyn2c.hop.clickbank.net',
            'provadent': 'https://2a4abbhbl5llqpudxlx9g02r3g.hop.clickbank.net',
            'aqua-tower': 'https://dc88ejpqditsroz2snhqpgtffb.hop.clickbank.net',
            'his-secret-obsession': 'https://8d4eagdfj5nk0l3-xfpotfmmp0.hop.clickbank.net',
            'shifting-vibrations': 'https://339adlddrhreygt9vf31yvex6c.hop.clickbank.net',
            'spiritual-salt': 'https://0a8babkbm6rpsgvn35md5v0u77.hop.clickbank.net',
            'billionaire-brain-wave': 'https://9ee2efeojeon1h33sfq-s6ru3o.hop.clickbank.net',
            'moon-reading': 'https://d85e76lnm6mprl0etj2fre3jct.hop.clickbank.net',
            'neuro-energizer': 'https://4971b8gbg9jd0eslgh6brlhqr2.hop.clickbank.net',
            'the-wealth-signal': 'https://ea4ee8oergoftdqop4slvjscaw.hop.clickbank.net',
            'the-genius-wave': 'https://8aa2ebfie9mmrh25sjnn2-2v6s.hop.clickbank.net',
            
            // Trading/VIP Indicators (mapped from PDF)
            'vip-indicators': 'https://922ba9inqbssuf311hxdos4ram.hop.clickbank.net',
            
            // Product with long filename - map to generic fallback
            'tra-v-di-i-n-p-g-in-t-d-o-m-ic-o-a-l-a-t-t-r-o-k-h-r-e-a-s-t-t---2-p-p-4-r-r-7-e-o-d-fi-ic-ta-ts-b-l-a-e-ny': 'https://hop.clickbank.net/?affiliate=marcketpro&vendor=generic',
            'trading-signals-starter': 'https://922ba9inqbssuf311hxdos4ram.hop.clickbank.net',
            
            // Kit Mappings (using primary product hoplinks)
            'vitalidade-50': 'https://b9714bhqo9tq-g1f4fbow9nz3t.hop.clickbank.net', // Daily Vitality Boost
            'sobrevivencia-premium': 'https://32e549kff9fltft7fi07sa2l3y.hop.clickbank.net', // Nagano Lean Belly Tonic
            'prosperidade-inteligente': 'https://922ba9inqbssuf311hxdos4ram.hop.clickbank.net', // VIP Indicators
            'conexao-completa': 'https://fb48ahbbohrf2ez2mjx7mo1euw.hop.clickbank.net', // Eden Longevity
            'equilibrio-metabolico': 'https://f03a2cngj8pj2cr9zhr9cc6i4e.hop.clickbank.net', // GlucoBerry
            'performance-mental': 'https://c52b4hggn8je4jvanp2lt0i6re.hop.clickbank.net', // NeuroQuiet
            'longevidade-ativa': 'https://1052c9qglcrp2hwxoatir1w6c8.hop.clickbank.net', // CelluCare
            'foco-energia': 'https://a3c30ffmkcmr4m194mz6kevnep.hop.clickbank.net', // Air Fountain
            
            // English Kit Names
            'oral-health-duo': 'https://f8138fknedfewbvl-kq0siric8.hop.clickbank.net', // ProDentim
            'hearing-clarity-support': 'https://81de1kdkp8qdzp0qihifsffuat.hop.clickbank.net', // ZenCortex
            'clean-air-water-pack': 'https://a3c30ffmkcmr4m194mz6kevnep.hop.clickbank.net', // Air Fountain
            'joint-mobility-essentials': 'https://29990gopd9ogtcx8qfztoy6pb6.hop.clickbank.net', // Ageless Knees
            'metabolic-balance-kit': 'https://f03a2cngj8pj2cr9zhr9cc6i4e.hop.clickbank.net', // GlucoBerry
            'cognitive-focus-stack': 'https://c52b4hggn8je4jvanp2lt0i6re.hop.clickbank.net', // NeuroQuiet
            'relationships-insights-bundle': 'https://095f9lfojeqkxmsrqrqqv4e-a1.hop.clickbank.net' // Soulmate Sketch
        };
    }

    openOffer(productSlug) {
        const hoplink = this.hoplinks[productSlug];
        if (hoplink) {
            // Add tracking parameters
            const trackingUrl = this.addTrackingParams(hoplink, productSlug);
            
            // Open in new tab
            window.open(trackingUrl, '_blank', 'noopener,noreferrer');
            
            // Track the click for analytics
            this.trackClick(productSlug);
        } else {
            console.error('Hoplink not found for product:', productSlug);
            // Fallback - try to find similar product
            const fallbackLink = this.findFallbackLink(productSlug);
            if (fallbackLink) {
                window.open(fallbackLink, '_blank', 'noopener,noreferrer');
            } else {
                alert('Product link temporarily unavailable. Please try again later.');
            }
        }
    }

    findFallbackLink(productSlug) {
        // Try to find similar products for fallback
        const similarMappings = {
            'placeholder-slot-28': 'https://6c2b5gnqsjihwdvdrkklzcyn2c.hop.clickbank.net' // Pineal Guardian X
        };
        return similarMappings[productSlug] || null;
    }

    addTrackingParams(hoplink, productSlug) {
        try {
            const url = new URL(hoplink);
            url.searchParams.set('source', 'smartconsumerdecision');
            url.searchParams.set('product', productSlug);
            url.searchParams.set('timestamp', Date.now().toString());
            return url.toString();
        } catch (error) {
            // If URL parsing fails, return original hoplink
            console.warn('Could not add tracking params to:', hoplink);
            return hoplink;
        }
    }

    trackClick(productSlug) {
        // Track click for analytics (Google Analytics, etc.)
        if (typeof gtag !== 'undefined') {
            gtag('event', 'click', {
                event_category: 'affiliate_link',
                event_label: productSlug,
                value: 1
            });
        }
        
        // Track with Google Tag Manager if available
        if (typeof dataLayer !== 'undefined') {
            dataLayer.push({
                event: 'affiliate_click',
                product_slug: productSlug,
                click_timestamp: new Date().toISOString()
            });
        }
        
        // Console log for debugging
        console.log('Affiliate click tracked:', productSlug);
    }

    // Method to validate all hoplinks (for testing)
    validateHoplinks() {
        const results = {};
        for (const [slug, link] of Object.entries(this.hoplinks)) {
            try {
                new URL(link);
                results[slug] = 'valid';
            } catch (error) {
                results[slug] = 'invalid';
                console.error(`Invalid hoplink for ${slug}:`, link);
            }
        }
        return results;
    }
}

// Global function for opening offers (called from HTML)
function openOffer(productSlug) {
    if (window.hoplinkManager) {
        window.hoplinkManager.openOffer(productSlug);
    } else {
        console.error('HoplinkManager not initialized');
        // Fallback - try to initialize and retry
        window.hoplinkManager = new HoplinkManager();
        setTimeout(() => {
            if (window.hoplinkManager) {
                window.hoplinkManager.openOffer(productSlug);
            }
        }, 100);
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.hoplinkManager = new HoplinkManager();
    
    // Add click handlers to all CTA buttons
    document.querySelectorAll('.cta-button, .view-offer-btn, [onclick*="openOffer"]').forEach(button => {
        if (!button.onclick) {
            const productSlug = button.getAttribute('data-product') || 
                               button.closest('[data-product]')?.getAttribute('data-product');
            if (productSlug) {
                button.onclick = () => openOffer(productSlug);
            }
        }
    });
});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = HoplinkManager;
}

