
// Enhanced Products and Kits Loader
class ProductKitLoader {
    constructor() {
        this.productsData = [];
        this.kitsData = [];
        this.init();
    }

    async init() {
        try {
            await this.loadData();
            this.renderFeaturedProducts();
            this.renderFeaturedKits();
            this.renderAllProducts();
            this.renderAllKits();
        } catch (error) {
            console.error('Error initializing ProductKitLoader:', error);
        }
    }

    async loadData() {
        try {
            const [productsResponse, kitsResponse] = await Promise.all([
                fetch('/assets/data/products.json'),
                fetch('/assets/data/kits.json')
            ]);
            
            this.productsData = await productsResponse.json();
            this.kitsData = await kitsResponse.json();
        } catch (error) {
            console.error('Error loading data:', error);
            // Fallback to empty arrays
            this.productsData = [];
            this.kitsData = [];
        }
    }

    renderFeaturedProducts() {
        const container = document.getElementById('featured-products');
        if (!container) return;

        const featured = this.productsData.slice(0, 6); // Show first 6 as featured
        container.innerHTML = this.createProductGrid(featured);
    }

    renderFeaturedKits() {
        const container = document.getElementById('featured-kits');
        if (!container) return;

        const featured = this.kitsData.slice(0, 3); // Show first 3 as featured
        container.innerHTML = this.createKitGrid(featured);
    }

    renderAllProducts() {
        const container = document.getElementById('all-products-list');
        if (!container) return;

        container.innerHTML = this.createProductGrid(this.productsData);
    }

    renderAllKits() {
        const container = document.getElementById('all-kits-list');
        if (!container) return;

        container.innerHTML = this.createKitGrid(this.kitsData);
    }

    createProductGrid(products) {
        if (!products.length) {
            return '<p>No products available at the moment.</p>';
        }

        return `
            <div class="product-grid">
                ${products.map(product => this.createProductCard(product)).join('')}
            </div>
        `;
    }

    createKitGrid(kits) {
        if (!kits.length) {
            return '<p>No kits available at the moment.</p>';
        }

        return `
            <div class="kit-grid">
                ${kits.map(kit => this.createKitCard(kit)).join('')}
            </div>
        `;
    }

    createProductCard(product) {
        return `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" loading="lazy">
                <h3>${product.name}</h3>
                <div class="smartscore-mini">
                    <span class="score-label">SmartScore:</span>
                    <span class="score-value">8.5</span>
                </div>
                <a href="/products/${product.slug}.html" class="card-link">Learn More</a>
            </div>
        `;
    }

    createKitCard(kit) {
        return `
            <div class="kit-card">
                <img src="${kit.image}" alt="${kit.name} Kit" loading="lazy">
                <h3>${kit.name} Kit</h3>
                <p class="kit-description">Comprehensive solution with ${kit.products.length} products</p>
                <div class="smartscore-mini">
                    <span class="score-label">SmartScore:</span>
                    <span class="score-value">8.7</span>
                </div>
                <a href="/kits/${kit.slug}.html" class="card-link">Learn More</a>
            </div>
        `;
    }
}

// Additional CSS for product/kit cards (to be added to style.css)
const additionalCSS = `
.product-grid, .kit-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.product-card, .kit-card {
    background: white;
    border-radius: 12px;
    padding: 1.5rem;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    text-align: center;
}

.product-card:hover, .kit-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}

.product-card img, .kit-card img {
    width: 100%;
    height: 200px;
    object-fit: cover;
    border-radius: 8px;
    margin-bottom: 1rem;
}

.product-card h3, .kit-card h3 {
    color: #2c3e50;
    margin-bottom: 1rem;
    font-size: 1.3rem;
}

.kit-description {
    color: #6c757d;
    font-size: 0.9rem;
    margin-bottom: 1rem;
}

.smartscore-mini {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
    padding: 0.5rem;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    border-radius: 6px;
}

.smartscore-mini .score-label {
    font-weight: 600;
    color: #495057;
}

.smartscore-mini .score-value {
    font-weight: 700;
    color: #28a745;
    font-size: 1.1rem;
}

.card-link {
    display: inline-block;
    background: linear-gradient(135deg, #007bff 0%, #0056b3 100%);
    color: white;
    padding: 0.75rem 1.5rem;
    text-decoration: none;
    border-radius: 6px;
    font-weight: 600;
    transition: all 0.3s ease;
}

.card-link:hover {
    background: linear-gradient(135deg, #0056b3 0%, #004085 100%);
    transform: translateY(-1px);
}
`;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new ProductKitLoader();
    
    // Add additional CSS
    const style = document.createElement('style');
    style.textContent = additionalCSS;
    document.head.appendChild(style);
});
