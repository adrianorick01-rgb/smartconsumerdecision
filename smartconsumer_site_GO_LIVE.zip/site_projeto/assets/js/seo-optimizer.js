// SEO Optimizer - SmartConsumerDecision.com
// Automatic SEO enhancements for better search engine visibility

class SEOOptimizer {
    constructor() {
        this.init();
    }

    init() {
        this.optimizeImages();
        this.addStructuredData();
        this.optimizeInternalLinks();
        this.addBreadcrumbs();
        this.optimizeHeadings();
    }

    // Optimize images with lazy loading and alt text
    optimizeImages() {
        document.querySelectorAll('img').forEach(img => {
            // Add loading="lazy" if not present
            if (!img.hasAttribute('loading')) {
                img.setAttribute('loading', 'lazy');
            }

            // Ensure alt text exists
            if (!img.hasAttribute('alt') || img.getAttribute('alt') === '') {
                const src = img.getAttribute('src') || '';
                const filename = src.split('/').pop().split('.')[0];
                const altText = filename.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                img.setAttribute('alt', altText);
            }

            // Add error handling for missing images
            img.addEventListener('error', function() {
                this.style.display = 'none';
                console.warn('Image failed to load:', this.src);
            });
        });
    }

    // Add structured data for better search results
    addStructuredData() {
        // Add Organization schema if not present
        if (!document.querySelector('script[type="application/ld+json"]')) {
            const organizationSchema = {
                "@context": "https://schema.org",
                "@type": "Organization",
                "name": "SmartConsumerDecision.com",
                "url": "https://www.smartconsumerdecision.com",
                "logo": "https://www.smartconsumerdecision.com/assets/img/site/main-logo-dark.webp",
                "description": "Objective product reviews and analysis using scientific methodology",
                "contactPoint": {
                    "@type": "ContactPoint",
                    "contactType": "customer service",
                    "url": "https://www.smartconsumerdecision.com/support.html"
                },
                "sameAs": [
                    "https://www.smartconsumerdecision.com"
                ]
            };

            const script = document.createElement('script');
            script.type = 'application/ld+json';
            script.textContent = JSON.stringify(organizationSchema);
            document.head.appendChild(script);
        }

        // Add WebSite schema for search functionality
        const websiteSchema = {
            "@context": "https://schema.org",
            "@type": "WebSite",
            "name": "SmartConsumerDecision.com",
            "url": "https://www.smartconsumerdecision.com",
            "potentialAction": {
                "@type": "SearchAction",
                "target": "https://www.smartconsumerdecision.com/search?q={search_term_string}",
                "query-input": "required name=search_term_string"
            }
        };

        const websiteScript = document.createElement('script');
        websiteScript.type = 'application/ld+json';
        websiteScript.textContent = JSON.stringify(websiteSchema);
        document.head.appendChild(websiteScript);
    }

    // Optimize internal links
    optimizeInternalLinks() {
        document.querySelectorAll('a[href^="/"], a[href^="./"], a[href^="../"]').forEach(link => {
            // Add title attribute if missing
            if (!link.hasAttribute('title') && link.textContent.trim()) {
                link.setAttribute('title', link.textContent.trim());
            }

            // Ensure internal links don't have target="_blank"
            if (link.hasAttribute('target') && link.getAttribute('target') === '_blank') {
                link.removeAttribute('target');
            }
        });

        // Optimize external links
        document.querySelectorAll('a[href^="http"]:not([href*="smartconsumerdecision.com"])').forEach(link => {
            // Add rel="noopener noreferrer" for security
            link.setAttribute('rel', 'noopener noreferrer');
            
            // Add target="_blank" for external links
            if (!link.hasAttribute('target')) {
                link.setAttribute('target', '_blank');
            }
        });
    }

    // Add breadcrumb navigation
    addBreadcrumbs() {
        const path = window.location.pathname;
        const pathParts = path.split('/').filter(part => part !== '');
        
        if (pathParts.length > 0) {
            const breadcrumbContainer = document.querySelector('.breadcrumbs') || 
                                      this.createBreadcrumbContainer();
            
            if (breadcrumbContainer) {
                const breadcrumbs = this.generateBreadcrumbs(pathParts);
                breadcrumbContainer.innerHTML = breadcrumbs;
                
                // Add structured data for breadcrumbs
                this.addBreadcrumbSchema(pathParts);
            }
        }
    }

    createBreadcrumbContainer() {
        const container = document.createElement('nav');
        container.className = 'breadcrumbs';
        container.setAttribute('aria-label', 'Breadcrumb navigation');
        
        const main = document.querySelector('main');
        if (main) {
            main.insertBefore(container, main.firstChild);
            return container;
        }
        return null;
    }

    generateBreadcrumbs(pathParts) {
        let breadcrumbs = '<ol class="breadcrumb-list">';
        breadcrumbs += '<li><a href="/">Home</a></li>';
        
        let currentPath = '';
        pathParts.forEach((part, index) => {
            currentPath += '/' + part;
            const isLast = index === pathParts.length - 1;
            const title = this.formatBreadcrumbTitle(part);
            
            if (isLast) {
                breadcrumbs += `<li class="current">${title}</li>`;
            } else {
                breadcrumbs += `<li><a href="${currentPath}/">${title}</a></li>`;
            }
        });
        
        breadcrumbs += '</ol>';
        return breadcrumbs;
    }

    formatBreadcrumbTitle(part) {
        const titleMap = {
            'products': 'Products',
            'kits': 'Kits',
            'blog': 'Blog',
            'about': 'About',
            'support': 'Support',
            'methodology': 'Methodology'
        };
        
        return titleMap[part] || part.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
    }

    addBreadcrumbSchema(pathParts) {
        const breadcrumbList = {
            "@context": "https://schema.org",
            "@type": "BreadcrumbList",
            "itemListElement": []
        };

        breadcrumbList.itemListElement.push({
            "@type": "ListItem",
            "position": 1,
            "name": "Home",
            "item": "https://www.smartconsumerdecision.com/"
        });

        let currentPath = '';
        pathParts.forEach((part, index) => {
            currentPath += '/' + part;
            breadcrumbList.itemListElement.push({
                "@type": "ListItem",
                "position": index + 2,
                "name": this.formatBreadcrumbTitle(part),
                "item": `https://www.smartconsumerdecision.com${currentPath}/`
            });
        });

        const script = document.createElement('script');
        script.type = 'application/ld+json';
        script.textContent = JSON.stringify(breadcrumbList);
        document.head.appendChild(script);
    }

    // Optimize heading structure
    optimizeHeadings() {
        const headings = document.querySelectorAll('h1, h2, h3, h4, h5, h6');
        let h1Count = 0;

        headings.forEach(heading => {
            if (heading.tagName === 'H1') {
                h1Count++;
                if (h1Count > 1) {
                    console.warn('Multiple H1 tags found. Consider using H2 for secondary headings.');
                }
            }

            // Ensure headings have proper hierarchy
            if (!heading.textContent.trim()) {
                console.warn('Empty heading found:', heading);
            }
        });

        // Add IDs to headings for anchor links
        headings.forEach(heading => {
            if (!heading.hasAttribute('id') && heading.textContent.trim()) {
                const id = heading.textContent.trim()
                    .toLowerCase()
                    .replace(/[^a-z0-9\s-]/g, '')
                    .replace(/\s+/g, '-')
                    .replace(/-+/g, '-')
                    .replace(/^-|-$/g, '');
                
                if (id && !document.getElementById(id)) {
                    heading.setAttribute('id', id);
                }
            }
        });
    }

    // Add canonical URL if missing
    addCanonicalURL() {
        if (!document.querySelector('link[rel="canonical"]')) {
            const canonical = document.createElement('link');
            canonical.rel = 'canonical';
            canonical.href = window.location.href.split('?')[0].split('#')[0];
            document.head.appendChild(canonical);
        }
    }

    // Optimize meta tags
    optimizeMetaTags() {
        // Ensure viewport meta tag exists
        if (!document.querySelector('meta[name="viewport"]')) {
            const viewport = document.createElement('meta');
            viewport.name = 'viewport';
            viewport.content = 'width=device-width, initial-scale=1.0';
            document.head.appendChild(viewport);
        }

        // Add robots meta tag if missing
        if (!document.querySelector('meta[name="robots"]')) {
            const robots = document.createElement('meta');
            robots.name = 'robots';
            robots.content = 'index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1';
            document.head.appendChild(robots);
        }

        // Add author meta tag
        if (!document.querySelector('meta[name="author"]')) {
            const author = document.createElement('meta');
            author.name = 'author';
            author.content = 'SmartConsumerDecision.com';
            document.head.appendChild(author);
        }
    }

    // Performance optimization
    optimizePerformance() {
        // Add preconnect for external resources
        const preconnects = [
            'https://fonts.googleapis.com',
            'https://fonts.gstatic.com',
            'https://www.google-analytics.com'
        ];

        preconnects.forEach(url => {
            if (!document.querySelector(`link[href="${url}"]`)) {
                const link = document.createElement('link');
                link.rel = 'preconnect';
                link.href = url;
                if (url.includes('gstatic')) {
                    link.crossOrigin = 'anonymous';
                }
                document.head.appendChild(link);
            }
        });

        // Add dns-prefetch for ClickBank
        if (!document.querySelector('link[href="//hop.clickbank.net"]')) {
            const dnsPrefetch = document.createElement('link');
            dnsPrefetch.rel = 'dns-prefetch';
            dnsPrefetch.href = '//hop.clickbank.net';
            document.head.appendChild(dnsPrefetch);
        }
    }
}

// Initialize SEO optimizer when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new SEOOptimizer();
});

// Export for testing
if (typeof module !== 'undefined' && module.exports) {
    module.exports = SEOOptimizer;
}

